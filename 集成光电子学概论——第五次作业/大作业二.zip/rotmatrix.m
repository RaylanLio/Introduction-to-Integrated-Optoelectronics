function R = rotmatrix(t)
% Generate the rotating matrix
%   Detailed explanation goes here
R=[cos(t) -sin(t);sin(t) cos(t)];
end